﻿
using FBISWebApi.DBAccess;
using FBISWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FBISWebApi.Logics
{
    public class PlanApproval
    {

        Operation IOperation = new Operation();
        public bool InsertForm1Details(FormOneEntity form)
        { 
            bool flag= Convert.ToBoolean(IOperation.DML("Insert_Form_One",form.Appname,form.Designation,form.App_add_line1,form.App_add_line2,form.App_post,form.App_taluk,form.App_district,form.App_Pincode,form.Phone_no,form.Factory_add_line1,form.Factory_add_line2,form.Factory_post,form.Factory_taluk,form.Factory_district,form.Factory_pincode,form.Factory_phone_no,form.Factory_name,form.Situation_f_district,form.Situation_f_town_village,form.nearest_police_station,form.nearest_rlystation,form.buldng_approval,form.Userid,form.division_cd,form.circle_cd,form.App_mob_No1,form.Email_id,form.App_mob_No2,form.CompanyType,form.Total_wrkr_emplyd,form.Amount,form.amt_words));

            return flag;
        }
    }
}