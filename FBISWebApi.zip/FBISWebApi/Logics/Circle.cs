﻿
using FBISWebApi.DBAccess;
using FBISWebApi.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace FBISWebApi.Logics
{
    public class Circle
    {
        Operation DbOperation = new Operation();

        // Get All Region
        public List<Region> GetRegion()
        {
            List<Region> cr = new List<Region>();
            // get region database using stored procedure
            DataSet allRegion = DbOperation.GetRecordAll("Sp_GetRegion");
            foreach(DataRow item in allRegion.Tables[0].Rows)
            {
                var religion = new Region
                {
                    CircleName = item[0].ToString(),
                    CircleCode=Convert.ToInt32(item[1])
                };
                cr.Add(religion);
            }
            return cr;
        }
        // get division by region
        public List<Division> GetDivision(string circleName)
        {
            List<Division> cd = new List<Division>();
            DataSet divisionByRegion = DbOperation.DDL("sp_Select_division", circleName);
            foreach (DataRow item in divisionByRegion.Tables[0].Rows)
            {
                var division = new Division
                {
                    DivName = item[0].ToString()
                };
                cd.Add(division);
            }
            return cd;
        }
    }
}