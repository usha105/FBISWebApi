﻿using FBISWebApi.Logics;
using FBISWebApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace FBISWebApi.Controllers
{
  
    public class HomeController : ApiController
    {
        [HttpGet]
        [Route("getallregion")]
        public IHttpActionResult Region()
        {
            Circle c = new Circle();
            var religion = JsonConvert.SerializeObject(c.GetRegion()).ToString();
            var json1 = religion.ToString().Replace("[{", "{Region:[{");
            var json2 = json1.ToString().Replace("}]", "}]}");
            JObject json = JObject.Parse(json2);
            return Ok(json);
        }
        [HttpGet]
        [Route("getdivisionbyregion")]
        public IHttpActionResult Division(string regionName)
        {
            Circle c = new Circle();
            var division = JsonConvert.SerializeObject(c.GetDivision(regionName)).ToString();
            var json1 = division.ToString().Replace("[{", "{Division:[{");
            var json2 = json1.ToString().Replace("}]", "}]}");
            JObject json = JObject.Parse(json2);
            return Ok(json);
        }

        [HttpPost]
        [Route("insertplanapproval")]
        public IHttpActionResult InsertPlanApproval(FormOneEntity request)
        {
            try
            { 
            FormOneEntity form = new FormOneEntity();
            PlanApproval PA = new PlanApproval();
            if (PA.InsertForm1Details(request))
            {

                Jsonresponse json = new Jsonresponse();
                json.status = "200 OK";
                json.statusMsg = "Record Inserted Successfully";
                string jo = JsonConvert.SerializeObject(json).ToString();
                JObject job = JObject.Parse(jo);
                return Ok(job);
            }
            else
            {
                return BadRequest();
            }
        }
            catch (Exception ex)
            {
        /*        logfile("Application No: " + request.);
        logfile("ApplicantName: " + request.data.ApplicantName, appRunningId);
        logfile("JobRefNo: " + request.data.JobRefNo, appRunningId);
        logfile("MobileNo: " + request.data.MobileNo, appRunningId);
        logfile("EMail: " + request.data.EMail, appRunningId);
        logfile("CreatedBy: " + request.data.CreatedBy, appRunningId);
        logfile("UpdatedBy: " + request.data.UpdatedBy, appRunningId);
        logfile("RecruitingOrganisationName: " + request.data.RecruitingOrganisationName, appRunningId);
        logfile("FathersName: " + request.data.FathersName, appRunningId);
        logfile("MothersName: " + request.data.MothersName, appRunningId);
        logfile("DateofBirth: " + request.data.DateofBirth, appRunningId);
        logfile("ApplicantName: " + request.data.CurrentAddressLine1, appRunningId);
        logfile("CurrentAddressLine2: " + request.data.CurrentAddressLine2, appRunningId);
        logfile("CurrentAddressLine3: " + request.data.CurrentAddressLine3, appRunningId);
        logfile("CurrentDistict: " + request.data.CurrentDistict, appRunningId);
        logfile("CurrentTaluk: " + request.data.CurrentTaluk, appRunningId);
        logfile("CurrentPincode: " + request.data.CurrentPincode, appRunningId);
        logfile("PermanentAddressLine1: " + request.data.PermanentAddressLine1, appRunningId);
        logfile("PermanentAddressLine2: " + request.data.PermanentAddressLine2, appRunningId);
        logfile("PermanentAddressLine2: " + request.data.PermanentAddressLine2, appRunningId);
        logfile("PermanentDistict: " + request.data.PermanentDistict, appRunningId);
        logfile("PermanentTaluk: " + request.data.PermanentTaluk, appRunningId);
        logfile("PermanentPincode: " + request.data.PermanentPincode, appRunningId);
        logfile("DeputyCommissioneroffice: " + request.data.DeputyCommissioneroffice, appRunningId);
        logfile("GroupValue: " + request.data.GroupValue, appRunningId);
        logfile("Designation: " + request.data.Designation, appRunningId);
        logfile("Caste: " + request.data.Caste, appRunningId);
        logfile("SubCaste: " + request.data.SubCaste, appRunningId);
        logfile("RDNumber: " + request.data.RDNumber, appRunningId);
        logfile("GroupValueOther: " + request.data.GroupValueOther, appRunningId);
        logfile("DepartmentName: " + request.data.DepartmentName, appRunningId);
        logfile("Religion: " + request.data.Religion, appRunningId);
        logfile("ApplId: " + request.spId.applId, appRunningId);
        logfile("Error" + ex, appRunningId);
             */   return BadRequest();
    }
}

public class Jsonresponse
{
    public string status { get; set; }
    public string statusMsg { get; set; }
}

static void logfile(string tasknames, string appRunningId)
{
    //string logpath = System.Configuration.ConfigurationSettings.AppSettings["logpath"].ToString();
    string logpath = AppDomain.CurrentDomain.BaseDirectory;
    string fileName1 = logpath + "\\Sindhuthva Pramana Patra" + DateTime.Now.ToString("ddMMyyyy") + ".txt";
    FileInfo fii = new FileInfo(fileName1);
    try
    {
        // Check if file already exists. append txtFile 
        if (fii.Exists)
        {
            // fii.Delete();
            using (StreamWriter sw = fii.AppendText())
            {
                sw.WriteLine("{0}---" + tasknames + "", DateTime.Now.ToString() + " -- " + appRunningId);
                sw.WriteLine("___________________________________");

            }
        }
        else
            // Create a new file                       
            using (StreamWriter sw = fii.CreateText())
            {
                sw.WriteLine("{0}---" + tasknames + "", DateTime.Now.ToString() + " -- " + appRunningId);
                sw.WriteLine("______________________________________");
            }
    }

    catch (Exception Ex)
    {
        logfile(Ex.Message + Ex.StackTrace, appRunningId);
    }
}
    }

}
