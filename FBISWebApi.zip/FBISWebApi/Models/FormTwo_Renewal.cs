﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FBISWebApi.Models
{
    public class FormTwo_Renewal
    {
    }
}